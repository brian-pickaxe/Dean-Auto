<?php
/**
 * Template Name: Pricing
 */
get_header();
$book_url = deanauto_book_url();
?>
<section class="page-hero">
	<div class="container">
		<h1>Pricing</h1>
		<p>Transparent pricing for all our mobile detailing services. Contact us for a custom quote based on your vehicle size and specific needs.</p>
	</div>
</section>
<section style="padding: 5rem 0;" class="bg-gray">
	<div class="container">
		<div class="pricing-grid">
			<div class="pricing-card">
				<h3>Express Detail</h3>
				<p class="price">Starting at $99</p>
				<p class="p-desc">Quick refresh for regular maintenance</p>
				<ul><li>Exterior hand wash and dry</li><li>Interior vacuum</li><li>Window cleaning</li><li>Tire shine and wheel face clean</li><li>Dashboard wipe-down</li><li>Door jambs</li></ul>
			</div>
			<div class="pricing-card">
				<h3>Wash &amp; Wax</h3>
				<p class="price">Starting at $135</p>
				<p class="p-desc">Exterior wash with paint protection</p>
				<ul><li>Hand wash and dry</li><li>Wheel and tire cleaning</li><li>Paint sealant or wax</li><li>Trim dressing</li><li>Window cleaning (outside)</li></ul>
			</div>
			<div class="pricing-card">
				<h3>Interior Detailing</h3>
				<p class="price">Starting at $150</p>
				<p class="p-desc">Complete interior cleaning and sanitization</p>
				<ul><li>Deep vacuuming</li><li>Dashboard and console cleaning</li><li>Seat cleaning and conditioning</li><li>Window cleaning (inside)</li><li>Door panel and trim</li><li>Air vent and trunk cleaning</li></ul>
			</div>
			<div class="pricing-card popular">
				<h3>Exterior Detailing</h3>
				<p class="price">Starting at $200</p>
				<p class="p-desc">Comprehensive exterior wash and protection</p>
				<ul><li>Hand wash and dry</li><li>Wheel and tire cleaning</li><li>Paint decontamination</li><li>Clay bar treatment</li><li>Wax application</li><li>Trim restoration</li><li>Window cleaning (outside)</li></ul>
			</div>
			<div class="pricing-card">
				<h3>Ceramic Coating</h3>
				<p class="price">Starting at $800</p>
				<p class="p-desc">Premium long-lasting paint protection</p>
				<ul><li>Full paint correction</li><li>Multi-layer ceramic coating</li><li>5+ years of protection</li><li>UV and chemical resistance</li><li>Hydrophobic surface</li><li>Maintenance kit included</li></ul>
			</div>
			<div class="pricing-card">
				<h3>Headlight Restoration</h3>
				<p class="price">Starting at $85</p>
				<p class="p-desc">Restore cloudy or yellowed headlights</p>
				<ul><li>Sand and polish to remove oxidation</li><li>UV-resistant sealant</li><li>Clearer, brighter light output</li><li>Single or pair pricing</li></ul>
			</div>
		</div>
		<div class="text-center">
			<a id="Setmore_button_iframe" href="<?php echo esc_url( $book_url ); ?>" class="btn btn-primary" style="padding: 1rem 2rem;">Book Now</a>
		</div>
	</div>
</section>
<?php get_footer(); ?>
