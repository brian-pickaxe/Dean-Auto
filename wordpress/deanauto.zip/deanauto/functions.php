<?php
/**
 * Dean Auto theme functions and setup
 */

function deanauto_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 120,
		'width'       => 400,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'deanauto' ),
	) );
}
add_action( 'after_setup_theme', 'deanauto_setup' );

function deanauto_scripts() {
	wp_enqueue_style( 'deanauto-style', get_stylesheet_uri(), array(), '1.0.0' );
	// Setmore booking script (loaded on all pages for Book Now button)
	wp_enqueue_script(
		'setmore-booking',
		'https://assets.setmore.com/integration/static/setmoreIframeLive.js',
		array(),
		null,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'deanauto_scripts' );

/** Book Now URL - change if your Setmore link changes */
function deanauto_book_url() {
	return 'https://deanautodetailers.setmore.com';
}
