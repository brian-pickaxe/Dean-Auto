</main>

<footer class="site-footer">
	<div class="container">
		<div class="footer-grid">
			<div>
				<h3>Dean Auto</h3>
				<p style="color: #9ca3af; margin-bottom: 1rem;">Professional mobile car detailing services in the North Denver suburbs. Quality service brought right to your doorstep.</p>
			</div>
			<div>
				<h4>Quick Links</h4>
				<ul style="list-style: none; padding: 0;">
					<li style="margin-bottom: 0.5rem;"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<li style="margin-bottom: 0.5rem;"><a href="<?php echo esc_url( home_url( '/pricing/' ) ); ?>">Pricing</a></li>
					<li style="margin-bottom: 0.5rem;"><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a></li>
					<li style="margin-bottom: 0.5rem;"><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a></li>
				</ul>
			</div>
			<div>
				<h4>Contact</h4>
				<address style="color: #9ca3af;">
					<p><a href="mailto:deanautodetailers95@gmail.com">deanautodetailers95@gmail.com</a></p>
					<p><a href="tel:+17208127070">(720) 812-7070</a></p>
					<p style="font-size: 0.875rem; margin-top: 1rem;">Thornton, CO · North Denver metro</p>
					<p style="font-size: 0.875rem;">Serving Thornton, Westminster, Brighton, and surrounding North Denver suburbs</p>
				</address>
			</div>
		</div>
		<div class="footer-bottom">
			<p>&copy; <?php echo date( 'Y' ); ?> Dean Auto. All rights reserved.</p>
			<p style="color: #9ca3af; margin-top: 0.25rem;">Hosted and SEO by <a href="https://milehighinternet.com" target="_blank" rel="noopener noreferrer">milehighinternet.com</a></p>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
