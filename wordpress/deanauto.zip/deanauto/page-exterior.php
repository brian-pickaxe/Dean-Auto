<?php
/**
 * Template Name: Exterior Detailing
 */
get_header();
$book_url = deanauto_book_url();
?>
<section class="bg-white border-b" style="border-bottom: 1px solid var(--gray-200);">
	<div class="container service-content" style="padding: 4rem 1rem;">
		<h1>Exterior Car Detailing &amp; Wash in Thornton, Westminster &amp; Brighton</h1>
		<p>Full exterior car detailing at your home or office in Thornton, Westminster, Brighton, and the North Denver area. We use professional-grade products including Koch Chemie and Adam's Polishes to restore shine, remove contaminants, and protect your paint with a lasting wax or sealant.</p>
		<p><a id="Setmore_button_iframe" href="<?php echo esc_url( $book_url ); ?>" class="btn btn-primary" style="padding: 0.75rem 2rem;">Book Now</a></p>
	</div>
</section>
<section style="padding: 4rem 0;">
	<div class="container service-content">
		<h2>What's Included in Our Exterior Detailing</h2>
		<ul>
			<li>Hand wash and dry</li>
			<li>Wheel and tire cleaning</li>
			<li>Paint decontamination</li>
			<li>Clay bar treatment</li>
			<li>Wax or sealant application</li>
			<li>Trim restoration</li>
			<li>Exterior window cleaning</li>
		</ul>
		<h2>Why Choose Dean Auto for Exterior Detailing</h2>
		<p>We use Koch Chemie protector wax and Adam's Polishes for wash, wax, and paint care. Every exterior detail is done by hand—no brushes or tunnels that can mar your finish.</p>
		<h2>Service Area &amp; Pricing</h2>
		<p>We serve Thornton, Westminster, Brighton, Northglenn, and surrounding North Denver communities. Exterior detailing starts at $200. <a href="<?php echo esc_url( home_url( '/pricing/' ) ); ?>" class="external">View pricing</a> or <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="external">contact us</a>. Book online to reserve your spot.</p>
		<div class="related">
			<h2>Other Automotive Services</h2>
			<p><a href="<?php echo esc_url( home_url( '/services/interior/' ) ); ?>" class="external">Interior detailing</a> · <a href="<?php echo esc_url( home_url( '/services/ceramic-coating/' ) ); ?>" class="external">Ceramic coating</a> · <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="external">Home</a></p>
		</div>
	</div>
</section>
<?php get_footer(); ?>
