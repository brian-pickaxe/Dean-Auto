<?php
/**
 * Template Name: Contact
 */
get_header();
?>
<section style="padding: 5rem 0;">
	<div class="container">
		<div class="text-center mb-8">
			<h1 class="section-title">Contact Us</h1>
			<p class="section-subtitle">Get in touch to schedule your appointment or ask any questions. We're here to help!</p>
		</div>
		<div class="contact-grid">
			<div class="contact-card">
				<div class="icon primary">Email</div>
				<h3>Email</h3>
				<a href="mailto:deanautodetailers95@gmail.com">deanautodetailers95@gmail.com</a>
			</div>
			<div class="contact-card">
				<div class="icon secondary">Phone</div>
				<h3>Phone</h3>
				<a href="tel:+17208127070">(720) 812-7070</a>
			</div>
			<div class="contact-card">
				<div class="icon primary">Area</div>
				<h3>Service Area</h3>
				<p style="color: var(--gray-600);">Thornton, Westminster, Brighton, and North Denver suburbs</p>
			</div>
		</div>
		<div class="hours-card">
			<h2 style="font-size: 1.875rem; font-weight: 700; color: var(--gray-900); margin-bottom: 1.5rem;">Business Hours</h2>
			<div class="hours-row"><span class="icon">Clock</span><div><p style="font-weight: 600; color: var(--gray-900);">Monday - Friday</p><p style="color: var(--gray-600);">8:00 AM - 6:00 PM</p></div></div>
			<div class="hours-row"><span class="icon">Clock</span><div><p style="font-weight: 600; color: var(--gray-900);">Saturday</p><p style="color: var(--gray-600);">9:00 AM - 5:00 PM</p></div></div>
			<div class="hours-row"><span class="icon">Clock</span><div><p style="font-weight: 600; color: var(--gray-900);">Sunday</p><p style="color: var(--gray-600);">By Appointment</p></div></div>
			<div style="margin-top: 2rem; padding: 1rem; background: var(--gray-50); border-radius: 0.5rem;">
				<p style="font-size: 0.875rem; color: var(--gray-600);">We offer flexible scheduling to accommodate your needs. Contact us to discuss custom appointment times.</p>
			</div>
		</div>
	</div>
</section>
<?php get_footer(); ?>
