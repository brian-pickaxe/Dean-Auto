<?php
/**
 * Template Name: Ceramic Coating
 */
get_header();
$book_url = deanauto_book_url();
?>
<section class="bg-white border-b" style="border-bottom: 1px solid var(--gray-200);">
	<div class="container service-content" style="padding: 4rem 1rem;">
		<h1>Ceramic Coating &amp; Paint Protection in Thornton, Westminster &amp; Brighton</h1>
		<p>Long-lasting paint protection with Adam's Graphene Ceramic Coating™ in Thornton, Westminster, Brighton, and the North Denver metro. We come to you for paint correction and multi-layer ceramic coating that delivers a hydrophobic, high-gloss finish for 5+ years.</p>
		<p><a id="Setmore_button_iframe" href="<?php echo esc_url( $book_url ); ?>" class="btn btn-primary" style="padding: 0.75rem 2rem;">Book Now</a></p>
	</div>
</section>
<section style="padding: 4rem 0;">
	<div class="container service-content">
		<h2>What's Included in Our Ceramic Coating Service</h2>
		<ul>
			<li>Paint correction (as needed)</li>
			<li>Multi-layer graphene ceramic coating</li>
			<li>5+ years of protection</li>
			<li>UV and chemical resistance</li>
			<li>Hydrophobic surface (water beading)</li>
			<li>Enhanced gloss and shine</li>
			<li>Maintenance kit included</li>
		</ul>
		<h2>Why Choose Dean Auto for Ceramic Coating</h2>
		<p>We use Adam's Graphene Ceramic Coating for durable, hydrophobic protection that lasts years. Before coating, we perform paint correction when necessary so the surface is smooth and defect-free.</p>
		<h2>Service Area &amp; Pricing</h2>
		<p>We serve the North Denver metro including Thornton, Westminster, Brighton, and Northglenn. Ceramic coating packages start at $800. <a href="<?php echo esc_url( home_url( '/pricing/' ) ); ?>" class="external">View pricing</a> or <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="external">contact us</a> for a custom quote.</p>
		<div class="related">
			<h2>Other Automotive Services</h2>
			<p><a href="<?php echo esc_url( home_url( '/services/interior/' ) ); ?>" class="external">Interior detailing</a> · <a href="<?php echo esc_url( home_url( '/services/exterior/' ) ); ?>" class="external">Exterior detailing</a> · <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="external">Home</a></p>
		</div>
	</div>
</section>
<?php get_footer(); ?>
